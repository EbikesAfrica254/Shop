import jwt    from "jsonwebtoken";
import dotenv from "dotenv";
dotenv.config();

/* ───────────────── authenticate ───────────────── */
export function authenticate(req, res, next) {
  const token = req.cookies?.token;
  if (!token) return res.status(401).json({ message: "Unauthenticated" });

  try {
    req.user = jwt.verify(token, process.env.JWT_SECRET);
    return next();
  } catch (err) {
    console.error("JWT verification failed:", err.message);
    // wipe the invalid cookie so the browser stops sending it
    res.clearCookie("token", { path: "/" });
    return res.status(401).json({ message: "Invalid / expired token" });
  }
}

/* ───────────────── authorize(role1, role2 …) ───────────────── */
export const authorize =
  (...roles) =>
  (req, res, next) => {
    // if no roles passed → allow any authenticated user
    if (roles.length && !roles.includes(req.user?.role))
      return res.status(403).json({ message: "Forbidden" });
    next();
  };
