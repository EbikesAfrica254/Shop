import mysql  from "mysql2/promise";
import dotenv from "dotenv";
dotenv.config();

const { DB_HOST, DB_USER, DB_PASS, DB_NAME } = process.env;

export let db;            // exported pool instance

export async function initDB() {
  /* 1 ▸ root connection (no DB yet) */
  const root = await mysql.createConnection({
    host: DB_HOST,
    user: DB_USER,
    password: DB_PASS,
  });

  /* 2 ▸ create database if needed */
  await root.query(`CREATE DATABASE IF NOT EXISTS \`${DB_NAME}\``);
  await root.query(`USE \`${DB_NAME}\``);

  /* 3 ▸ ensure tables */

  // employees
  await root.query(`
    CREATE TABLE IF NOT EXISTS employees (
      id            INT AUTO_INCREMENT PRIMARY KEY,
      full_name     VARCHAR(100) NOT NULL,
      id_number     VARCHAR(20)  NOT NULL UNIQUE,
      phone         VARCHAR(20)  NOT NULL,
      email         VARCHAR(100) NOT NULL UNIQUE,
      code          CHAR(6)      NOT NULL,
      password_hash CHAR(60)     NOT NULL,
      role          ENUM('pending','admin','manager','cashier','employee')
                    NOT NULL DEFAULT 'pending',
      suspended     TINYINT(1) NOT NULL DEFAULT 0,
      created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );
  `);

  // items
  await root.query(`
    CREATE TABLE IF NOT EXISTS items (
      id              INT AUTO_INCREMENT PRIMARY KEY,
      category        VARCHAR(60)  NOT NULL,
      name            VARCHAR(120) NOT NULL,
      description     TEXT,
      detail          TEXT,
      price           DECIMAL(10,2) NOT NULL,
      discount        TINYINT(1) NOT NULL DEFAULT 0,
      discount_amount DECIMAL(10,2),
      discount_reason VARCHAR(255),
      suspended       TINYINT(1) NOT NULL DEFAULT 0,
      stock_update    TINYINT(1) NOT NULL DEFAULT 1,
      created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      share_link      VARCHAR(255),
      INDEX idx_cat_name (category, name)
    );
  `);

  // item_images (NEW)
  await root.query(`
    CREATE TABLE IF NOT EXISTS item_images (
      id        INT AUTO_INCREMENT PRIMARY KEY,
      item_id   INT NOT NULL,
      file_name VARCHAR(100) NOT NULL,
      INDEX idx_item (item_id),
      FOREIGN KEY (item_id) REFERENCES items(id) ON DELETE CASCADE
    );
  `);

  await root.end();

  /* 4 ▸ pooled connection for app */
  db = mysql.createPool({
    host: DB_HOST,
    user: DB_USER,
    password: DB_PASS,
    database: DB_NAME,
    waitForConnections: true,
    connectionLimit: 10,
  });
}
