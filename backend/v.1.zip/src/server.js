// src/server.js
import express      from "express";
import cors         from "cors";
import cookieParser from "cookie-parser";
import dotenv       from "dotenv";
import path         from "node:path";
import fs           from "node:fs";

import { initDB, db }   from "./config/db.js";
import employeeRoutes   from "./routes/employees.js";
import itemRoutes       from "./routes/items.js";
import { authenticate } from "./middleware/auth.js";

dotenv.config();

async function startServer() {
  await initDB();                           // DB + tables ensured

  /* ─ create uploads dir once ─ */
  const uploadsPath = path.join("uploads/items");
  fs.mkdirSync(uploadsPath, { recursive: true });
  console.log(`📁 Uploads directory created/verified: ${path.resolve(uploadsPath)}`);

  const app = express();

  /* ─ CORS (use env var or fall back to localhost) ─ */
  app.use(cors({
    origin: process.env.FRONTEND_URL ?? "http://localhost:5173",
    credentials: true,
  }));

  app.use(express.json());
  app.use(cookieParser());

  /* ─ Debug middleware to log all requests ─ */
  app.use((req, res, next) => {
    if (req.url.startsWith('/uploads') || req.url.startsWith('/api')) {
      console.log(`📋 ${req.method} ${req.url}`);
    }
    next();
  });

  /* ─ static images with detailed logging ─ */
  app.use("/uploads/items", (req, res, next) => {
    const requestedFile = path.join(uploadsPath, req.url);
    console.log(`📷 Image requested: ${req.url}`);
    console.log(`📍 Full path: ${requestedFile}`);
    
    // Check if file exists
    if (fs.existsSync(requestedFile)) {
      console.log(`✅ File exists: ${requestedFile}`);
    } else {
      console.log(`❌ File not found: ${requestedFile}`);
      
      // List what files DO exist in the directory
      try {
        const dirPath = path.dirname(requestedFile);
        if (fs.existsSync(dirPath)) {
          const files = fs.readdirSync(dirPath);
          console.log(`📁 Files in ${dirPath}:`, files);
        } else {
          console.log(`📁 Directory doesn't exist: ${dirPath}`);
        }
      } catch (err) {
        console.log(`📁 Error reading directory: ${err.message}`);
      }
    }
    next();
  }, express.static(path.resolve("uploads/items")));

  /* ─ health check ─ */
  app.get("/api/health", async (_req, res) => {
    try { 
      await db.query("SELECT 1"); 
      res.json({ 
        ok: true, 
        uploads_path: path.resolve(uploadsPath),
        server_time: new Date().toISOString()
      }); 
    }
    catch (error) { 
      res.status(500).json({ 
        ok: false, 
        error: "DB offline",
        details: error.message 
      }); 
    }
  });

  /* ─ test endpoint for uploads directory ─ */
  app.get("/api/test-uploads", (req, res) => {
    try {
      const uploadsDir = path.resolve("uploads/items");
      const exists = fs.existsSync(uploadsDir);
      
      let structure = {};
      if (exists) {
        try {
          const items = fs.readdirSync(uploadsDir);
          items.forEach(item => {
            const itemPath = path.join(uploadsDir, item);
            const stats = fs.statSync(itemPath);
            if (stats.isDirectory()) {
              try {
                const files = fs.readdirSync(itemPath);
                structure[item] = files.map(file => ({
                  name: file,
                  url: `${req.protocol}://${req.get('host')}/uploads/items/${item}/${file}`,
                  size: fs.statSync(path.join(itemPath, file)).size
                }));
              } catch (err) {
                structure[item] = `Error: ${err.message}`;
              }
            }
          });
        } catch (err) {
          structure = { error: err.message };
        }
      }

      res.json({
        uploads_directory_exists: exists,
        uploads_path: uploadsDir,
        base_url: `${req.protocol}://${req.get('host')}`,
        structure: structure,
        sample_urls: exists && Object.keys(structure).length > 0 
          ? Object.values(structure)[0]?.map?.(f => f.url) || []
          : []
      });
    } catch (error) {
      res.status(500).json({
        error: "Failed to check uploads",
        message: error.message
      });
    }
  });

  /* ─ auth helpers ─ */
  app.get("/api/auth/me", authenticate, (req, res) =>
    res.json({ role: req.user.role })
  );

  app.post("/api/auth/logout", (_req, res) =>
    res.clearCookie("token", {
      httpOnly: true,
      sameSite: "strict",
      secure  : process.env.NODE_ENV === "production",
      path    : "/",
    }).json({ message:"Logged out" })
  );

  /* ─ main routes ─ */
  app.use("/api/employees", employeeRoutes);
  app.use("/api/items",     itemRoutes);

  /* ─ fallback 404 for unknown API routes ─ */
  app.use("/api", (_req, res) => res.status(404).json({ message:"Not found" }));

  /* ─ catch-all for testing static file serving ─ */
  app.get("/test-image", (req, res) => {
    res.send(`
      <html>
        <body>
          <h1>Image Serving Test</h1>
          <p>If you have images in uploads/items/1/, they should appear below:</p>
          <img src="/uploads/items/1/1.jpg" alt="Test 1" style="max-width: 300px; border: 1px solid #ccc;" 
               onerror="this.style.display='none'; this.nextElementSibling.style.display='block';" />
          <p style="display: none; color: red;">Image 1.jpg not found</p>
          
          <img src="/uploads/items/1/2.jpg" alt="Test 2" style="max-width: 300px; border: 1px solid #ccc;" 
               onerror="this.style.display='none'; this.nextElementSibling.style.display='block';" />
          <p style="display: none; color: red;">Image 2.jpg not found</p>
          
          <hr>
          <p><a href="/api/test-uploads">Check uploads directory structure</a></p>
          <p><a href="/api/items/public">Check items API</a></p>
        </body>
      </html>
    `);
  });

  /* ─ boot ─ */
  const PORT = process.env.PORT || 5000;
  app.listen(PORT, () => {
    console.log(`🚀 API server running on port ${PORT}`);
    console.log(`📁 Uploads directory: ${path.resolve(uploadsPath)}`);
    console.log(`🌐 Test image serving: http://localhost:${PORT}/test-image`);
    console.log(`🔧 Test uploads: http://localhost:${PORT}/api/test-uploads`);
    console.log(`📦 Items API: http://localhost:${PORT}/api/items/public`);
  });
}

startServer().catch(err => {
  console.error("❌ Failed to start server:", err);
  process.exit(1);
});